//
//  BSChatBotClient.h
//  BSChatBotClient
//
//  Created by Tarek Sabry on 23/02/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for BSChatBotClient.
FOUNDATION_EXPORT double BSChatBotClientVersionNumber;

//! Project version string for BSChatBotClient.
FOUNDATION_EXPORT const unsigned char BSChatBotClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BSChatBotClient/PublicHeader.h>


