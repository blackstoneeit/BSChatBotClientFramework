# Introduction 
DUChatBot SDK is to handle user messages with the automated bot, In addition to handle one to one and one to many agents sessions

# Getting Started
You can install latest version from chatbot through cocoapods

```
pod BSChatBotFramework
```
this shall install the SDK and its dependencies

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
To Publish a new version for the SDK 
* Your account needs to be added to both SDK projects on github
    * https://github.com/blackstoneeit/BSChatBotClientFramework
    * https://github.com/blackstoneeit/DuChatBotFramework
* Your account needs to be added by "blackstoneeit@gmail.com" as owner for the cocoapod
* You need to use an xCode version other than 14.3 or 14.3.1 as they have bugs that makes publishing commands return errors. Instead we can use 14.2

# Publishing Steps

### Step :one:: Extract xcFramework from source code folder:

In source code folder run this terminal command

for BSChatBotFramework
```
 sh build_du_chatbot_xcframework.sh
```

for DuChatBotClientFramework

```
 sh build_chatbot_client_xcframework.sh
```
This will archive and build an xcFramework for you in the same folder

### Step :two:: Prepare your pod project for publishing:

<li> Clone git project into your device</li>
<li> replace the xcFramework with your newly generated one</li>
<li> update your podspec file with a new version number</li>
<li> comment and push the updates to github</li>
<li> source code in the podspec needs to refere to xcframework zipped file of the previouse version, you may need to add it there manually</li>

### Step :three:: Publishing commands:

Here is a sample publish process on BSChatBotFramework

Note: all commands shall be ran while terminal is located to project root folder

>1- Add new tag

```
 git tag 2.2.8
```
tag number refere to the new pod version. it have to match the one in podspec file

then we push the new tag as following:
```
 git push origin 2.2.8
```

>2- Validate the framework for publishing

```
 pod lib lint  --verbose --no-clean --allow-warnings --swift-version=5
```
if passed with no error we can move to the publishing command

>2- Publishing the framework to cocoapods

```
 pod trunk push --verbose --allow-warnings
```

if this has no errors the framework shall be published successfully.

## Note
If you have problems in cocoapods CDN server you will need to run all commands while using VPN App
